"""Tests that the specification artifacts agree with the kernel data.

The kernel, the JSON schemas, and the OWL module are three statements of one
thing. These tests check that they remain three statements of one thing.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from rkernel.validate import (
    check_kernel,
    check_owl_agreement,
    check_reasoning,
    check_schemas,
    run_all,
)
from rkernel import load_kernel

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def kernel():
    return load_kernel()


def test_kernel_check_passes(kernel):
    assert check_kernel(kernel)["ok"] is True


def test_kernel_and_chains_validate_against_their_schemas():
    result = check_schemas()
    if result["ok"] is None:
        pytest.skip(result["skipped"])
    assert result["ok"] is True, result["problems"]
    assert result["validated"] >= 5, "kernel plus every bundled chain"


def test_owl_locus_mask_agrees_with_the_kernel(kernel):
    result = check_owl_agreement(kernel)
    if result["ok"] is None:
        pytest.skip(result["skipped"])
    assert result["ok"] is True, result
    # 14, not 17: three of the seventeen exclusions are at the artifact body,
    # which is not a chain specification and so has no parthood axiom to state.
    assert result["exclusions_in_owl"] == result["exclusions_in_kernel"] == 14
    assert result["gating_axiom_present"] is True


def test_the_gating_rule_is_enforced_not_merely_documented():
    """The load-bearing check. Asserting a Stratum D crossing at an absent link
    must make the ontology inconsistent under a reasoner."""
    result = check_reasoning()
    if result["ok"] is None:
        pytest.skip(result.get("skipped", "reasoner unavailable"))
    assert result["example_abox" if "example_abox" in result else "example-abox"] == "consistent"
    assert result["gating-violation"] == "inconsistent"
    assert result["ok"] is True, result["problems"]


def test_run_all_reports_ok():
    report = run_all()
    assert report["ok"] is True
    assert "Validation report" in report["markdown"]


def test_owl_module_is_regenerable_and_unchanged():
    """The OWL module is generated from kernel.json. If regenerating it changes
    the file, the checked-in copy is stale."""
    import subprocess
    import sys

    ttl = ROOT / "spec" / "owl" / "recognition-kernel.ttl"
    if not ttl.is_file():
        pytest.skip("spec/owl not present")
    before = ttl.read_text(encoding="utf-8")
    subprocess.run(
        [sys.executable, str(ROOT / "tools" / "build_owl.py")],
        check=True, capture_output=True,
    )
    assert ttl.read_text(encoding="utf-8") == before, (
        "spec/owl/recognition-kernel.ttl is stale; run tools/build_owl.py and commit"
    )


def test_every_primitive_documented_in_primitives_md(kernel):
    doc = (ROOT / "spec" / "PRIMITIVES.md").read_text(encoding="utf-8")
    for primitive in kernel.primitives:
        assert f"### {primitive.id} " in doc, primitive.id


def test_spec_records_the_grid_total(kernel):
    """The 69/70 discrepancy must stay visible in the prose spec."""
    doc = (ROOT / "spec" / "SPEC.md").read_text(encoding="utf-8")
    assert "70 of 84" in doc
    assert "sixty-nine" in doc


# --------------------------------------------------------------------------
# BFO conformance
# --------------------------------------------------------------------------


def test_no_absent_link_individuals_are_minted():
    """The previous ABox asserted seven chain-link individuals for the Gene
    Ontology and gave each a status of absent, positing an entity in order to
    deny it exists. Absence of a link is absence of a part."""
    abox = ROOT / "spec" / "owl" / "example-abox.ttl"
    if not abox.is_file():
        pytest.skip("spec/owl not present")
    text = abox.read_text(encoding="utf-8")
    assert "rk:Absent" not in text
    assert "hasStatus" not in text
    go_block = text.split("Gene Ontology: no chain specifications")[-1]
    assert "Specification" not in go_block.replace("no chain specifications", "")


def test_primitives_are_classes_not_individuals(kernel):
    """Universals are classes. Their instances are particular contradictions in
    particular artifacts."""
    ttl = ROOT / "spec" / "owl" / "recognition-kernel.ttl"
    if not ttl.is_file():
        pytest.skip("spec/owl not present")
    text = ttl.read_text(encoding="utf-8")
    for primitive in kernel.primitives:
        assert f"rk:{primitive.owl_class} a owl:Class" in text, primitive.id
        assert f"rk:{primitive.owl_class} a owl:NamedIndividual" not in text


def test_every_primitive_has_a_genus_differentia_definition(kernel):
    for primitive in kernel.primitives:
        definition = primitive.genus_differentia
        assert definition, primitive.id
        assert definition.startswith(("A ", "An ")), primitive.id
        assert " that " in definition, primitive.id


def test_locus_is_mereological_not_a_bespoke_relation():
    ttl = ROOT / "spec" / "owl" / "recognition-kernel.ttl"
    if not ttl.is_file():
        pytest.skip("spec/owl not present")
    text = ttl.read_text(encoding="utf-8")
    assert "rk:atLocus" not in text
    assert "rk:Crossing" not in text
    assert "obo:BFO_0000050" in text


def test_external_terms_are_registered(kernel):
    """Every OBO IRI the module uses must be in the registry that
    tools/check_bfo.py verifies. An unregistered IRI is never checked."""
    ttl = ROOT / "spec" / "owl" / "recognition-kernel.ttl"
    if not ttl.is_file():
        pytest.skip("spec/owl not present")
    import re

    used = set(re.findall(r"obo:([A-Z]+_\d+)", ttl.read_text(encoding="utf-8")))
    registered = set(kernel.bfo["external_terms"])
    assert used - registered == set(), f"unregistered: {sorted(used - registered)}"


def test_the_two_part_status_model_is_present(kernel):
    """The configuration WHO occupies for Chapter 26 must be statable: a
    declaration exists and no role is asserted to inhere in anyone."""
    ttl = ROOT / "spec" / "owl" / "recognition-kernel.ttl"
    if not ttl.is_file():
        pytest.skip("spec/owl not present")
    text = ttl.read_text(encoding="utf-8")
    assert "rk:ConferredStatusRole a owl:Class" in text
    assert "rk:StatusDeclaration a owl:Class" in text
    assert "rk:DeclarationWithoutBorneRole" in text
    decision = next(d for d in kernel.bfo["decisions"] if d["id"] == "D1")
    assert "two-part" in decision["decision"].lower()


def test_named_types_are_inferred_not_looked_up():
    """A domain typology is a theorem of the product. Named types are defined
    classes, so a reasoner classifies into them without being told."""
    from rkernel.validate import check_reasoning

    result = check_reasoning()
    if result["ok"] is None:
        pytest.skip(result.get("skipped", "reasoner unavailable"))
    inferred = result["inferred_named_types"]
    assert "RepairFailure" in inferred.get("FRCPClash", [])
    assert "ResidualIndeterminacy" in inferred.get("ICD11Residual", [])


def test_mask_and_gating_fail_separately():
    """Two claims, two negative tests. A suite testing only the gating rule
    would not notice the locus mask being dropped."""
    from rkernel.validate import check_reasoning

    result = check_reasoning()
    if result["ok"] is None:
        pytest.skip(result.get("skipped", "reasoner unavailable"))
    assert result["gating-violation"] == "inconsistent"
    assert result["mask-violation"] == "inconsistent"


def test_reasoning_reports_whether_bfo_axioms_were_loaded():
    """A consistency verdict reached without BFO's axioms present is a weaker
    claim than it looks, and the report must say which was run."""
    from rkernel.validate import check_reasoning

    result = check_reasoning()
    if result["ok"] is None:
        pytest.skip(result.get("skipped", "reasoner unavailable"))
    assert "bfo_axioms_loaded" in result
    assert result["scope"].startswith(("full:", "partial:"))


# --------------------------------------------------------------------------
# Handbook
# --------------------------------------------------------------------------


def test_handbook_covers_every_primitive(kernel):
    doc = (ROOT / "HANDBOOK.md").read_text(encoding="utf-8")
    for primitive in kernel.primitives:
        assert primitive.id in doc, primitive.id
        assert primitive.name in doc, primitive.name


def test_handbook_states_the_gating_rule_correctly(kernel):
    doc = (ROOT / "HANDBOOK.md").read_text(encoding="utf-8")
    for status, value in kernel.gating_rule["values"].items():
        assert status in doc
    assert "cannot fire" in doc and "fires only rarely" in doc


def test_handbook_grid_total_matches_the_kernel(kernel):
    doc = (ROOT / "HANDBOOK.md").read_text(encoding="utf-8")
    chain_loci = [locus.id for locus in kernel.chain_loci]
    total = kernel.well_formed_cells(chain_loci)
    cells = len(kernel.primitives) * len(chain_loci)
    assert f"{total} of the {cells}" in doc, f"handbook should say {total} of the {cells}"


def test_handbook_links_resolve():
    """Every relative link in the handbook must point at a file that exists."""
    import re

    doc = (ROOT / "HANDBOOK.md").read_text(encoding="utf-8")
    targets = re.findall(r"\]\((?!http)([^)#]+)\)", doc)
    missing = [t for t in targets if not (ROOT / t).exists()]
    assert not missing, f"broken links: {missing}"
