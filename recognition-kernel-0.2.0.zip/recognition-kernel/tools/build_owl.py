#!/usr/bin/env python3
"""Generate spec/owl/recognition-kernel.ttl from data/kernel.json.

BFO 2020 conformant. Run `tools/check_bfo.py` afterwards in an environment
where BFO, IAO and RO resolve; a mistyped external IRI declares a fresh class
silently rather than failing, which is how an ontology comes to claim an
alignment it does not have.

What conformance changed
------------------------
**Universals are classes.** The twelve primitives were OWL individuals. Their
instances are particular contradictions in particular artifacts, so they are
classes, and each carries an Aristotelian definition and a definition source.

**Contradictions are information content entities.** A contradiction is a
continuant part of the artifact's ICE. Not a quality: two printings of one code
carry the same contradiction, so the entity is generically dependent rather than
inhering in a material bearer.

**Locus is mereology.** A contradiction at the criteria locus is one that is
part of a criteria specification. There is no `atLocus` relation and no crossing
individual; `BFO_0000050 part of` does the work, and the locus mask becomes a
set of unsatisfiability axioms over parthood.

**Absence is absence of a part.** The previous ABox minted seven chain-link
individuals for the Gene Ontology and gave each a status of `absent`, positing
an entity in order to deny that it exists. An artifact now either has a
specification part of the relevant kind or it does not, and act-emptiness is a
universal restriction rather than a value.

**Crossings and firing values are not entities.** Crossings become defined
classes, so a reasoner classifies a contradiction into its named type instead of
an application matching coordinates in a table. Firing values are rate claims
and live in annotations, since a rate is not something the world contains.

**Status is two-part.** A ConferredStatusRole inheres in the bearer; a
StatusDeclaration is about it. The recognition act outputs the declaration. The
configuration in which a declaration exists and no role is borne is a defined
class, because that configuration is WHO's stated position on ICD-11 Chapter 26
and neither a pure role nor a pure GDC model can express it.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KERNEL = ROOT / "data" / "kernel.json"
OUT = ROOT / "spec" / "owl" / "recognition-kernel.ttl"

SOURCE = (
    "Koepsell, D. R., The Recognition Layer: A Generative Typology of Structural "
    "Contradiction for Recognition-Constituted Domains (working draft)."
)


def escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")


def article(class_name: str) -> str:
    spaced = "".join(f" {ch.lower()}" if ch.isupper() else ch for ch in class_name).strip()
    return ("an " if spaced[0] in "aeiou" else "a ") + spaced


def primitive_label(kernel: dict, primitive_id: str) -> str:
    for primitive in kernel["primitives"]:
        if primitive["id"] == primitive_id:
            return primitive["name"].lower()
    return primitive_id


def header(kernel: dict) -> str:
    decisions = "\n\n".join(
        f"{item['id']}. {item['question']} {item['decision']} Rationale: {item['rationale']}"
        for item in kernel["bfo"]["decisions"]
    )
    return f'''@prefix rk:   <https://sool.davidkoepsell.com/ontology/rk#> .
@prefix owl:  <http://www.w3.org/2002/07/owl#> .
@prefix rdf:  <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd:  <http://www.w3.org/2001/XMLSchema#> .
@prefix dct:  <http://purl.org/dc/terms/> .
@prefix obo:  <http://purl.obolibrary.org/obo/> .

<https://sool.davidkoepsell.com/ontology/rk> a owl:Ontology ;
    owl:imports <{kernel['bfo']['import_iri']}> ;
    dct:title "The Recognition Kernel"@en ;
    dct:creator "David R. Koepsell" ;
    dct:license <https://creativecommons.org/licenses/by/4.0/> ;
    dct:source "{escape(SOURCE)}" ;
    owl:versionInfo "{kernel['kernel_version']}" ;
    rdfs:comment """Twelve contradiction primitives in four strata, indexed over the seven links of a recognition chain. BFO 2020 conformant. Generated from data/kernel.json; do not edit by hand.

{escape(decisions)}"""@en .

#################################################################
#    Annotation properties (IAO)
#################################################################

obo:IAO_0000115 a owl:AnnotationProperty ; rdfs:label "definition"@en .
obo:IAO_0000116 a owl:AnnotationProperty ; rdfs:label "editor note"@en .
obo:IAO_0000119 a owl:AnnotationProperty ; rdfs:label "definition source"@en .

rk:firingValue a owl:AnnotationProperty ;
    rdfs:label "firing value"@en ;
    obo:IAO_0000116 "A rate claim about a class of contradiction in a kind of system. Carried as an annotation rather than as an axiom because a rate is not something the world contains, and because the middle value is an empirical claim that could turn out false without anything in the ontology being wrong."@en .

rk:detectionInstrument a owl:AnnotationProperty ;
    rdfs:label "detection instrument"@en .

rk:operationalized a owl:AnnotationProperty ;
    rdfs:label "operationalized"@en ;
    obo:IAO_0000116 "Whether a detector for this class exists in the current release. Absence of a detector is never to be reported as absence of the failure."@en .

#################################################################
#    Object properties
#
#    Parthood, aboutness, realization and output are BFO, IAO and RO
#    relations. Only two properties are local, and each is local because
#    no imported relation has its shape.
#################################################################

rk:prescribes a owl:ObjectProperty ;
    rdfs:label "prescribes"@en ;
    rdfs:domain obo:IAO_0000033 ;
    obo:IAO_0000115 "A relation between a directive information entity and an occurrent or realizable entity, holding when the former specifies the conditions under which the latter is to occur or be borne."@en ;
    obo:IAO_0000116 "Local because IAO has no relation of this shape. If one is adopted upstream, replace this and regenerate."@en .

rk:conferredBy a owl:ObjectProperty ;
    rdfs:label "conferred by"@en ;
    rdfs:domain obo:BFO_0000023 ;
    rdfs:range obo:BFO_0000015 ;
    obo:IAO_0000115 "A relation between a role and the process in which that role came to be borne."@en .
'''


def domain_block() -> str:
    return '''
#################################################################
#    Artifacts and chain specifications
#
#    A recognition chain is not an object with seven parts that may each
#    be present or absent. It is a set of specifications, each of which
#    an artifact either has as a part or does not. Absence of a link is
#    absence of a part, and no individual is minted for it.
#################################################################

rk:RecognitionArtifact a owl:Class ;
    rdfs:subClassOf obo:IAO_0000030 ;
    rdfs:label "recognition artifact"@en ;
    obo:IAO_0000115 "An information content entity that specifies one or more links of a recognition chain, or that supplies definitional content applied in one."@en ;
    obo:IAO_0000119 "%(source)s" .

rk:SourceArtifact a owl:Class ;
    rdfs:subClassOf rk:RecognitionArtifact ;
    rdfs:label "source artifact"@en ;
    obo:IAO_0000115 "A recognition artifact that is the governing text of a system, as promulgated by its authority."@en .

rk:FormalizedArtifact a owl:Class ;
    rdfs:subClassOf rk:RecognitionArtifact ;
    rdfs:label "formalized artifact"@en ;
    obo:IAO_0000115 "A recognition artifact that is about a source artifact and that renders its content in a formal language."@en ;
    rdfs:subClassOf [ a owl:Restriction ; owl:onProperty obo:IAO_0000136 ;
                      owl:someValuesFrom rk:SourceArtifact ] ;
    obo:IAO_0000116 "This distinction carries the provenance question. A contradiction that is part of a formalized artifact is a defect of the translation; one that is part of a source artifact is a defect of the source. The two present identically to a reasoner and must never be conflated in a report."@en .

[ a owl:AllDisjointClasses ; owl:members ( rk:SourceArtifact rk:FormalizedArtifact ) ] .

rk:ChainSpecification a owl:Class ;
    rdfs:subClassOf obo:IAO_0000033 ;
    rdfs:label "chain specification"@en ;
    obo:IAO_0000115 "A directive information entity that is a continuant part of a recognition artifact and that specifies one link of a recognition chain."@en ;
    rdfs:subClassOf [ a owl:Restriction ; owl:onProperty obo:BFO_0000050 ;
                      owl:someValuesFrom rk:RecognitionArtifact ] .

rk:InternallyPerformedSpecification a owl:Class ;
    rdfs:subClassOf rk:ChainSpecification ;
    rdfs:label "internally performed specification"@en ;
    obo:IAO_0000115 "A chain specification whose prescribed occurrent is carried out by a bearer of a role conferred under the authority of the same artifact."@en .

rk:ExternallyPerformedSpecification a owl:Class ;
    rdfs:subClassOf rk:ChainSpecification ;
    rdfs:label "externally performed specification"@en ;
    obo:IAO_0000115 "A chain specification whose prescribed occurrent is carried out by a bearer of a role that is not conferred under the authority of the same artifact."@en ;
    obo:IAO_0000116 "A classification specifies criteria in full and has them applied by clinicians it does not license. Its criteria specification is therefore of this class, not the internally performed one, and reading it the other way reports the pragmatic stratum as firing at full rate on the artifact's thickest link."@en .

[ a owl:AllDisjointClasses ;
  owl:members ( rk:InternallyPerformedSpecification rk:ExternallyPerformedSpecification ) ] .

#################################################################
#    Occurrents, roles, and the two-part conferred status
#################################################################

rk:RecognitionAct a owl:Class ;
    rdfs:subClassOf obo:BFO_0000015 ;
    rdfs:label "recognition act"@en ;
    obo:IAO_0000115 "A process in which a bearer of an assessor role applies criteria to presenting facts and thereby produces a status declaration."@en ;
    rdfs:subClassOf [ a owl:Restriction ; owl:onProperty obo:RO_0002234 ;
                      owl:someValuesFrom rk:StatusDeclaration ] ,
                    [ a owl:Restriction ; owl:onProperty obo:BFO_0000055 ;
                      owl:someValuesFrom rk:AssessorRole ] .

rk:RemedyProcess a owl:Class ;
    rdfs:subClassOf obo:BFO_0000015 ;
    rdfs:label "remedy process"@en ;
    obo:IAO_0000115 "A process in which a status declaration produced by a prior recognition act is revisited."@en ;
    obo:IAO_0000116 "Revision of the criteria is not a remedy process. It changes what future acts will apply; it does not revisit a conferral. Conflating the two is the commonest error in assigning a chain to a classification."@en .

rk:AuthorityRole a owl:Class ;
    rdfs:subClassOf obo:BFO_0000023 ;
    rdfs:label "authority role"@en ;
    obo:IAO_0000115 "A role borne by an independent continuant and realized in processes of fixing the criteria applied in a recognition act."@en .

rk:AssessorRole a owl:Class ;
    rdfs:subClassOf obo:BFO_0000023 ;
    rdfs:label "assessor role"@en ;
    obo:IAO_0000115 "A role borne by an independent continuant, conferred by a bearer of an authority role, and realized in recognition acts."@en .

rk:ConferredStatusRole a owl:Class ;
    rdfs:subClassOf obo:BFO_0000023 ;
    rdfs:label "conferred status role"@en ;
    obo:IAO_0000115 "A role borne by an independent continuant, which came to be borne in a recognition act, and which is realized in the effects that follow from that act."@en ;
    rdfs:subClassOf [ a owl:Restriction ; owl:onProperty rk:conferredBy ;
                      owl:someValuesFrom rk:RecognitionAct ] ;
    obo:IAO_0000116 "Half of the two-part model; the other half is rk:StatusDeclaration. Separating them is what lets the ontology represent a system that records a status while declining to assert that anything inheres in the bearer."@en .

rk:StatusDeclaration a owl:Class ;
    rdfs:subClassOf obo:IAO_0000030 ;
    rdfs:label "status declaration"@en ;
    obo:IAO_0000115 "An information content entity that is the output of a recognition act and that is about the independent continuant to which the act was addressed."@en ;
    rdfs:subClassOf [ a owl:Restriction ; owl:onProperty obo:IAO_0000136 ;
                      owl:someValuesFrom obo:BFO_0000004 ] .

rk:DeclarationWithoutBorneRole a owl:Class ;
    rdfs:label "declaration without borne role"@en ;
    owl:equivalentClass [ a owl:Class ; owl:intersectionOf (
        rk:StatusDeclaration
        [ a owl:Restriction ; owl:onProperty obo:IAO_0000136 ; owl:someValuesFrom
          [ a owl:Class ; owl:complementOf
            [ a owl:Restriction ; owl:onProperty obo:BFO_0000053 ;
              owl:someValuesFrom rk:ConferredStatusRole ] ] ] ) ] ;
    obo:IAO_0000115 "A status declaration about an independent continuant that bears no corresponding conferred status role."@en ;
    obo:IAO_0000116 "This class exists to make a position statable, not to be inferred: under the open world assumption nothing is classified here without a closure axiom. It is the configuration WHO occupies for ICD-11 Chapter 26, where the classification mandates recording and dual coding while declining to assert that any disposition inheres in the patient. A pure role model cannot represent it, because typing the pattern as a role asserts the very thing WHO withholds. A pure generically dependent continuant model cannot represent it either, because a generically dependent continuant does not inhere, so there is no bearer about which the assertion could be withheld."@en .
''' % {"source": escape(SOURCE)}


def spec_class_block(kernel: dict) -> str:
    parts = []
    for locus in kernel["loci"]:
        name = locus.get("owl_specification_class")
        if not name:
            continue
        described = locus["definition"].rstrip(".")
        described = described[0].lower() + described[1:]
        parts.append(
            f'''rk:{name} a owl:Class ;
    rdfs:subClassOf rk:ChainSpecification ;
    rdfs:label "{escape(locus['label'].lower())} specification"@en ;
    obo:IAO_0000115 "A chain specification that specifies {escape(described)}."@en .
'''
        )
    names = [
        f"rk:{locus['owl_specification_class']}"
        for locus in kernel["loci"]
        if locus.get("owl_specification_class")
    ]
    parts.append("[ a owl:AllDisjointClasses ; owl:members ( " + " ".join(names) + " ) ] .\n")
    return (
        "\n#################################################################\n"
        "#    The seven links, as specification classes\n"
        "#################################################################\n\n"
        + "\n".join(parts)
    )


def contradiction_block(kernel: dict) -> str:
    parts = [
        '''
#################################################################
#    Contradictions
#
#    A contradiction is an information content entity that is a
#    continuant part of the artifact bearing it. Not a quality: two
#    printings of one code carry the same contradiction, so the entity
#    is generically dependent rather than inhering in a material bearer.
#################################################################

rk:StructuralContradiction a owl:Class ;
    rdfs:subClassOf obo:IAO_0000030 ;
    rdfs:label "structural contradiction"@en ;
    obo:IAO_0000115 "An information content entity that is a continuant part of a recognition artifact and whose parts stand in a relation that artifact cannot sustain."@en ;
    obo:IAO_0000119 "%(source)s" ;
    rdfs:subClassOf [ a owl:Restriction ; owl:onProperty obo:BFO_0000050 ;
                      owl:someValuesFrom rk:RecognitionArtifact ] .

rk:ContradictionFinding a owl:Class ;
    rdfs:subClassOf obo:IAO_0000027 ;
    rdfs:label "contradiction finding"@en ;
    obo:IAO_0000115 "A data item that is about a structural contradiction and that records the detector, parameters and adjudication status under which it was returned."@en ;
    rdfs:subClassOf [ a owl:Restriction ; owl:onProperty obo:IAO_0000136 ;
                      owl:someValuesFrom rk:StructuralContradiction ] .

rk:SourceLevelFinding a owl:Class ;
    rdfs:label "source-level finding"@en ;
    owl:equivalentClass [ a owl:Class ; owl:intersectionOf (
        rk:ContradictionFinding
        [ a owl:Restriction ; owl:onProperty obo:IAO_0000136 ; owl:someValuesFrom
          [ a owl:Class ; owl:intersectionOf ( rk:StructuralContradiction
            [ a owl:Restriction ; owl:onProperty obo:BFO_0000050 ;
              owl:someValuesFrom rk:SourceArtifact ] ) ] ] ) ] ;
    obo:IAO_0000115 "A contradiction finding about a structural contradiction that is part of a source artifact."@en .

rk:TranslationLevelFinding a owl:Class ;
    rdfs:label "translation-level finding"@en ;
    owl:equivalentClass [ a owl:Class ; owl:intersectionOf (
        rk:ContradictionFinding
        [ a owl:Restriction ; owl:onProperty obo:IAO_0000136 ; owl:someValuesFrom
          [ a owl:Class ; owl:intersectionOf ( rk:StructuralContradiction
            [ a owl:Restriction ; owl:onProperty obo:BFO_0000050 ;
              owl:someValuesFrom rk:FormalizedArtifact ] ) ] ] ) ] ;
    obo:IAO_0000115 "A contradiction finding about a structural contradiction that is part of a formalized artifact."@en ;
    obo:IAO_0000116 "Provenance is a matter of which artifact the contradiction is part of, not a label on the report. The largest single source of artifactual incoherence in extraction pipelines has been a category misuse of the bearer-of relation, which produces a defect of exactly this class while presenting as one of the previous class."@en .
''' % {"source": escape(SOURCE)}
    ]

    for stratum in kernel["strata"]:
        gated = (
            "Gated by the presence of a recognition act specification."
            if stratum["gated"]
            else "Ungated: the precondition lies inside the artifact."
        )
        parts.append(
            f'''rk:{stratum['owl_class']} a owl:Class ;
    rdfs:subClassOf rk:StructuralContradiction ;
    rdfs:label "{escape(stratum['label'].lower())} contradiction"@en ;
    obo:IAO_0000115 "{escape(stratum['genus_differentia'])}"@en ;
    obo:IAO_0000116 "Stratum {stratum['id']}. Precondition: {escape(stratum['precondition'])}. {gated}"@en .
'''
        )
    parts.append(
        "[ a owl:AllDisjointClasses ; owl:members ( "
        + " ".join(f"rk:{stratum['owl_class']}" for stratum in kernel["strata"])
        + " ) ] .\n"
    )

    stratum_class = {stratum["id"]: stratum["owl_class"] for stratum in kernel["strata"]}
    for primitive in kernel["primitives"]:
        precedents = primitive.get("precedents", [])
        precedent_line = (
            "\n    obo:IAO_0000119 "
            + " , ".join(f'"{escape(item)}"' for item in precedents)
            + " ;"
            if precedents
            else ""
        )
        operationalized = primitive.get("operationalized", False)
        op_value = (
            "true"
            if operationalized is True
            else '"partial"'
            if operationalized == "partial"
            else "false"
        )
        parts.append(
            f'''rk:{primitive['owl_class']} a owl:Class ;
    rdfs:subClassOf rk:{stratum_class[primitive['stratum']]} ;
    rdfs:label "{escape(primitive['name'].lower())}"@en ;
    obo:IAO_0000115 "{escape(primitive['genus_differentia'])}"@en ;{precedent_line}
    rk:detectionInstrument "{escape(primitive.get('instrument', ''))}" ;
    rk:operationalized {op_value} ;
    obo:IAO_0000116 "{escape(primitive['id'])}. Formal signature: {escape(primitive.get('formal_signature', ''))} {escape(primitive.get('operationalization_note', ''))}"@en .
'''
        )
    parts.append(
        "[ a owl:AllDisjointClasses ; owl:members ( "
        + " ".join(f"rk:{primitive['owl_class']}" for primitive in kernel["primitives"])
        + " ) ] .\n"
    )
    return "\n".join(parts)


def locus_mask_block(kernel: dict) -> str:
    spec = {locus["id"]: locus.get("owl_specification_class") for locus in kernel["loci"]}
    parts = [
        '''
#################################################################
#    The locus mask, as unsatisfiability axioms over parthood
#
#    A crossing is well-formed when the locus supplies the structure the
#    primitive presupposes. Each axiom below says that a contradiction of
#    a given class, part of a specification of a given kind, is
#    unsatisfiable. Asserting one makes the ontology inconsistent.
#
#    Locus is mereological here. A contradiction at the criteria locus
#    simply is one that is part of a criteria specification.
#################################################################
'''
    ]
    for primitive in kernel["primitives"]:
        for locus_id in primitive.get("excluded_at", []):
            name = spec[locus_id]
            if not name:  # the artifact body is not a chain specification
                continue
            locus = next(item for item in kernel["loci"] if item["id"] == locus_id)
            parts.append(
                f'''[ a owl:Class ;
  owl:intersectionOf ( rk:{primitive['owl_class']}
                       [ a owl:Restriction ; owl:onProperty obo:BFO_0000050 ;
                         owl:someValuesFrom rk:{name} ] ) ;
  rdfs:subClassOf owl:Nothing ;
  obo:IAO_0000116 "{escape(primitive['id'])} is not well-formed at {escape(locus['label'].lower())}. {escape(primitive.get('well_formedness_rationale', ''))}"@en ] .
'''
            )
    return "\n".join(parts)


GATING = '''
#################################################################
#    The gating rule, as an unsatisfiability axiom over parthood
#
#    Strata A, B and C are ungated: their preconditions are rules,
#    definitions and top-level kinds, all of which lie inside the
#    artifact. Stratum D requires acts. An artifact specifying no
#    recognition act therefore cannot bear a pragmatic contradiction,
#    and the axiom below says so in a form a reasoner can check.
#
#    The universal restriction supplies the closure the open world
#    assumption otherwise denies: an act-empty artifact is one all of
#    whose parts fail to be recognition act specifications.
#################################################################

rk:ActEmptyArtifact a owl:Class ;
    rdfs:label "act-empty artifact"@en ;
    owl:equivalentClass [ a owl:Class ; owl:intersectionOf (
        rk:RecognitionArtifact
        [ a owl:Restriction ; owl:onProperty obo:BFO_0000051 ; owl:allValuesFrom
          [ a owl:Class ; owl:complementOf rk:RecognitionActSpecification ] ] ) ] ;
    obo:IAO_0000115 "A recognition artifact no continuant part of which is a recognition act specification."@en ;
    obo:IAO_0000116 "An empty pragmatic stratum here is a diagnosis of kind, not a clean audit: it reports that the artifact describes or classifies rather than decides. Strata A, B and C fire in such an artifact exactly as they do in a legal code."@en .

rk:ActThinArtifact a owl:Class ;
    rdfs:label "act-thin artifact"@en ;
    owl:equivalentClass [ a owl:Class ; owl:intersectionOf (
        rk:RecognitionArtifact
        [ a owl:Restriction ; owl:onProperty obo:BFO_0000051 ; owl:someValuesFrom
          [ a owl:Class ; owl:intersectionOf ( rk:RecognitionActSpecification
                                               rk:ExternallyPerformedSpecification ) ] ] ) ] ;
    obo:IAO_0000115 "A recognition artifact having as continuant part a recognition act specification whose prescribed act is carried out by a bearer of a role not conferred under the authority of that artifact."@en .

rk:ActThickArtifact a owl:Class ;
    rdfs:label "act-thick artifact"@en ;
    owl:equivalentClass [ a owl:Class ; owl:intersectionOf (
        rk:RecognitionArtifact
        [ a owl:Restriction ; owl:onProperty obo:BFO_0000051 ; owl:someValuesFrom
          [ a owl:Class ; owl:intersectionOf ( rk:RecognitionActSpecification
                                               rk:InternallyPerformedSpecification ) ] ] ) ] ;
    obo:IAO_0000115 "A recognition artifact having as continuant part a recognition act specification whose prescribed act is carried out by a bearer of a role conferred under the authority of that artifact."@en .

[ a owl:AllDisjointClasses ; owl:members ( rk:ActEmptyArtifact rk:ActThinArtifact ) ] .

[ a owl:Class ;
  owl:intersectionOf ( rk:PragmaticContradiction
                       [ a owl:Restriction ; owl:onProperty obo:BFO_0000050 ;
                         owl:someValuesFrom rk:ActEmptyArtifact ] ) ;
  rdfs:subClassOf owl:Nothing ;
  obo:IAO_0000116 "The gating rule. A pragmatic contradiction cannot be part of an artifact specifying no recognition act. Asserting one makes the ontology inconsistent, which is the falsification condition of the registered design in machine-checkable form."@en ] .
'''


def named_type_block(kernel: dict) -> str:
    spec = {locus["id"]: locus.get("owl_specification_class") for locus in kernel["loci"]}
    primitive_class = {p["id"]: p["owl_class"] for p in kernel["primitives"]}
    parts = [
        '''
#################################################################
#    Named types, as defined classes
#
#    Domain typologies are theorems of the product, not lists compiled
#    by observation. Each type below is defined by its coordinates, so a
#    reasoner classifies a contradiction into its named type rather than
#    an application looking those coordinates up in a table.
#################################################################
'''
    ]
    for named in kernel.get("named_types", []):
        locus_class = spec[named["locus"]]
        genus = primitive_class[named["primitive"]]
        reading = named.get("reading") or named.get("source", "")
        if locus_class:
            body = f'''    owl:equivalentClass [ a owl:Class ; owl:intersectionOf (
        rk:{genus}
        [ a owl:Restriction ; owl:onProperty obo:BFO_0000050 ;
          owl:someValuesFrom rk:{locus_class} ] ) ] ;
'''
            definition = (
                f"A {primitive_label(kernel, named['primitive'])} that is a continuant part of "
                f"{article(locus_class)}."
            )
        else:
            body = f"    rdfs:subClassOf rk:{genus} ;\n"
            definition = (
                f"A {primitive_label(kernel, named['primitive'])} that is a continuant part of "
                "the artifact body rather than of any chain specification."
            )
        parts.append(
            f'''rk:{named['owl_class']} a owl:Class ;
    rdfs:label "{escape(named['label'].lower())}"@en ;
{body}    obo:IAO_0000115 "{escape(definition)}"@en ;
    obo:IAO_0000116 "{escape(named['key'])}. {escape(reading)} Scope: {escape(named.get('system_kind') or 'any system kind')}."@en .
'''
        )
    return "\n".join(parts)


PROPERTY_TERMS = {
    "BFO_0000050", "BFO_0000051", "BFO_0000052", "BFO_0000053", "BFO_0000054",
    "BFO_0000055", "BFO_0000056", "BFO_0000057", "BFO_0000058", "BFO_0000059",
    "IAO_0000136", "RO_0002234",
}
ANNOTATION_TERMS = {"IAO_0000115", "IAO_0000116", "IAO_0000119"}
INVERSES = [("BFO_0000050", "BFO_0000051"), ("BFO_0000052", "BFO_0000053"),
            ("BFO_0000054", "BFO_0000055"), ("BFO_0000056", "BFO_0000057"),
            ("BFO_0000058", "BFO_0000059")]


def build_stub(kernel: dict) -> str:
    """Bare declarations for the external terms, for offline reasoning only.

    The module imports BFO properly. But where the import cannot be resolved, an
    undeclared `obo:BFO_0000050` is not an error: the reasoner treats the
    restriction built on it as inert, the gating axiom quietly stops firing, and
    the consistency check passes for the wrong reason. That failure is worse than
    a missing check, because it looks like a passing one.

    This file supplies the declarations and nothing else. It asserts no BFO
    axiom, so a run against it verifies this module's own axioms and NOTHING
    about the alignment. tools/check_bfo.py is what verifies the alignment, and
    it is also what catches this stub drifting from the real ontologies.
    """
    lines = ['@prefix owl:  <http://www.w3.org/2002/07/owl#> .',
             '@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .',
             '@prefix obo:  <http://purl.obolibrary.org/obo/> .',
             '',
             '<https://sool.davidkoepsell.com/ontology/rk/bfo-stub> a owl:Ontology ;',
             '    rdfs:label "External term declarations (offline fallback)"@en ;',
             '    rdfs:comment """Declarations only, for reasoning where BFO, IAO and RO cannot be resolved. NO BFO AXIOM IS ASSERTED HERE. A consistency verdict reached against this file verifies the recognition kernel\'s own axioms and nothing whatever about its alignment to BFO. Run tools/check_bfo.py against the real ontologies for that."""@en .',
             '']
    for local, label in sorted(kernel["bfo"]["external_terms"].items()):
        if local in ANNOTATION_TERMS:
            kind = "owl:AnnotationProperty"
        elif local in PROPERTY_TERMS:
            kind = "owl:ObjectProperty"
        else:
            kind = "owl:Class"
        lines.append(f'obo:{local} a {kind} ; rdfs:label "{escape(label)}"@en .')
    lines.append("")
    for left, right in INVERSES:
        if left in kernel["bfo"]["external_terms"] and right in kernel["bfo"]["external_terms"]:
            lines.append(f"obo:{left} owl:inverseOf obo:{right} .")
    return "\n".join(lines) + "\n"


def build(kernel: dict) -> str:
    return "".join(
        [
            header(kernel),
            domain_block(),
            spec_class_block(kernel),
            contradiction_block(kernel),
            locus_mask_block(kernel),
            GATING,
            named_type_block(kernel),
        ]
    )


def main() -> int:
    with KERNEL.open(encoding="utf-8") as handle:
        kernel = json.load(handle)

    # Keep the packaged copy in step. Two copies of a source of truth is one
    # too many, and the failure mode is silent: an edit to the canonical file
    # is ignored while every check still reports pass.
    packaged = ROOT / "src" / "rkernel" / "data" / "kernel.json"
    if packaged.parent.is_dir():
        packaged.write_text(KERNEL.read_text(encoding="utf-8"), encoding="utf-8")
        print(f"synced {packaged.relative_to(ROOT)}")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(build(kernel), encoding="utf-8")
    print(f"wrote {OUT.relative_to(ROOT)}")

    stub = OUT.parent / "bfo-stub.ttl"
    stub.write_text(build_stub(kernel), encoding="utf-8")
    print(f"wrote {stub.relative_to(ROOT)}")

    try:
        from rdflib import Graph

        graph = Graph()
        graph.parse(OUT, format="turtle")
        rdfxml = OUT.with_suffix(".owl")
        graph.serialize(destination=rdfxml, format="xml")
        print(f"wrote {rdfxml.relative_to(ROOT)} ({len(graph)} triples)")
    except ImportError:  # pragma: no cover
        print("rdflib not installed; skipped RDF/XML serialisation", file=sys.stderr)

    print(
        "\nRun tools/check_bfo.py where BFO, IAO and RO resolve. A mistyped external "
        "IRI\ndeclares a fresh class silently rather than failing."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
