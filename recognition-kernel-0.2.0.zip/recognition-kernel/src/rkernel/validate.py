"""Validation: the kernel, the schemas, and the OWL module must agree.

Four checks, each of which can fail independently:

1. **Kernel self-check.** Every primitive assigns every locus to exactly one of
   well_formed_at or excluded_at; every named type sits at a well-formed
   crossing.
2. **Schema validation.** kernel.json validates against kernel.schema.json, and
   every bundled chain against chain.schema.json.
3. **OWL agreement.** The locus mask asserted in the OWL module is the locus
   mask in kernel.json, primitive for primitive.
4. **Reasoning.** The ABox example is consistent and the gating-violation file
   is inconsistent. The second check is the load-bearing one: it verifies that
   the gating rule is actually enforced rather than merely documented.

Checks 2-4 degrade gracefully when jsonschema, rdflib, or a reasoner is absent,
and say so rather than passing silently.
"""

from __future__ import annotations

import json
from pathlib import Path

from .kernel import Kernel, default_kernel_path, load_kernel


def _root() -> Path:
    """Locate the repository root: the nearest ancestor holding `spec/schema`.

    When the package is installed, `kernel.json` resolves to the copy under
    `src/rkernel/data/`, whose parent is not the repository. Walking up for the
    spec directory finds the root in both layouts, and returns a path that
    simply does not exist when the package is installed standalone without the
    spec, which the checks below report as a skip rather than a failure.
    """
    for candidate in [Path.cwd(), *Path(__file__).resolve().parents]:
        if (candidate / "spec" / "schema").is_dir():
            return candidate
    return default_kernel_path().parent.parent


def check_kernel(kernel: Kernel) -> dict:
    problems = kernel.self_check()
    chain_loci = [locus.id for locus in kernel.chain_loci]
    return {
        "name": "kernel self-check",
        "ok": not problems,
        "problems": problems,
        "primitives": len(kernel.primitives),
        "loci": len(kernel.loci),
        "chain_loci": len(chain_loci),
        "well_formed_over_chain_loci": kernel.well_formed_cells(chain_loci),
        "cells_over_chain_loci": len(kernel.primitives) * len(chain_loci),
    }


def check_schemas(kernel_path: Path | None = None) -> dict:
    try:
        import jsonschema
    except ImportError:
        return {"name": "schema validation", "ok": None, "skipped": "jsonschema not installed"}

    root = _root()
    if not (root / "spec" / "schema").is_dir():
        return {
            "name": "schema validation",
            "ok": None,
            "skipped": "spec/ not present; run from a checkout of the repository",
        }
    problems: list[str] = []
    checked = 0

    pairs: list[tuple[Path, Path]] = [
        (kernel_path or default_kernel_path(), root / "spec" / "schema" / "kernel.schema.json")
    ]
    chain_schema = root / "spec" / "schema" / "chain.schema.json"
    for chain_file in sorted((root / "examples").rglob("*.chain.json")):
        pairs.append((chain_file, chain_schema))

    for instance_path, schema_path in pairs:
        if not instance_path.is_file() or not schema_path.is_file():
            problems.append(f"missing file: {instance_path} or {schema_path}")
            continue
        with instance_path.open(encoding="utf-8") as handle:
            instance = json.load(handle)
        with schema_path.open(encoding="utf-8") as handle:
            schema = json.load(handle)
        instance.pop("$schema", None)
        try:
            jsonschema.validate(instance, schema)
            checked += 1
        except jsonschema.ValidationError as error:
            problems.append(f"{instance_path.name}: {error.message} at {list(error.path)}")

    return {
        "name": "schema validation",
        "ok": not problems,
        "validated": checked,
        "problems": problems,
    }


def check_owl_agreement(kernel: Kernel) -> dict:
    try:
        from rdflib import Graph, Namespace, RDFS
    except ImportError:
        return {"name": "OWL agreement", "ok": None, "skipped": "rdflib not installed"}

    ttl = _root() / "spec" / "owl" / "recognition-kernel.ttl"
    if not ttl.is_file():
        return {
            "name": "OWL agreement",
            "ok": None,
            "skipped": "spec/owl/ not present; run from a checkout, or run tools/build_owl.py",
        }

    graph = Graph()
    graph.parse(ttl, format="turtle")
    RK = Namespace("https://sool.davidkoepsell.com/ontology/rk#")

    query = """
    PREFIX obo: <http://purl.obolibrary.org/obo/>
    SELECT ?p ?l WHERE {
      ?axiom rdfs:subClassOf owl:Nothing ;
             owl:intersectionOf ?list .
      ?list rdf:rest*/rdf:first ?p .
      FILTER(isIRI(?p))
      ?list rdf:rest*/rdf:first ?r .
      ?r owl:onProperty obo:BFO_0000050 ; owl:someValuesFrom ?l .
      FILTER(isIRI(?l))
    }
    """
    owl_exclusions = set()
    for primitive_iri, locus_iri in graph.query(query):
        pair = (str(primitive_iri).split("#")[-1], str(locus_iri).split("#")[-1])
        # The gating axiom shares the shape of a mask axiom but is not one: it
        # excludes a whole stratum from a kind of artifact, not a primitive
        # from a locus. It is checked separately by the reasoning test.
        if pair == ("PragmaticContradiction", "ActEmptyArtifact"):
            continue
        owl_exclusions.add(pair)

    # Locus is mereological now: the mask is stated as parthood in a
    # specification class, not as a value on an `atLocus` property.
    spec_class = {locus.id: locus.owl_specification_class for locus in kernel.loci}
    expected = {
        (primitive.owl_class, spec_class[locus_id])
        for primitive in kernel.primitives
        for locus_id in primitive.excluded_at
        if spec_class.get(locus_id)
    }

    missing = sorted(expected - owl_exclusions)
    extra = sorted(owl_exclusions - expected)
    gating_present = any(
        str(p).endswith("PragmaticContradiction") and str(l).endswith("ActEmptyArtifact")
        for p, l in graph.query(query)
    )
    return {
        "name": "OWL agreement",
        "gating_axiom_present": gating_present,
        "ok": not missing and not extra and gating_present,
        "exclusions_in_kernel": len(expected),
        "exclusions_in_owl": len(owl_exclusions),
        "missing_from_owl": missing,
        "not_in_kernel": extra,
    }


def check_reasoning() -> dict:
    """Consistency of the ABox, inconsistency of the gating violation."""
    try:
        import owlready2
    except ImportError:
        return {"name": "reasoning", "ok": None, "skipped": "owlready2 not installed"}

    owl_dir = _root() / "spec" / "owl"
    rdfxml = owl_dir / "recognition-kernel.owl"
    if not rdfxml.is_file():
        return {
            "name": "reasoning",
            "ok": None,
            "skipped": "recognition-kernel.owl not built; run tools/build_owl.py",
        }

    bfo_present = _bfo_available()
    results: dict[str, object] = {
        "name": "reasoning",
        "bfo_axioms_loaded": bfo_present,
        "scope": (
            "full: BFO, IAO and RO axioms loaded, so upper-level disjointness is in force"
            if bfo_present
            else "partial: BFO could not be resolved, so only this module's own axioms are "
                 "checked. The locus mask and the gating rule are verified; alignment to BFO "
                 "is NOT. Run tools/check_bfo.py where the imports resolve."
        ),
    }
    problems: list[str] = []

    for label, abox, expect_consistent in (
        ("example-abox", owl_dir / "example-abox.ttl", True),
        ("gating-violation", owl_dir / "gating-violation.ttl", False),
        ("mask-violation", owl_dir / "mask-violation.ttl", False),
    ):
        consistent = _is_consistent(rdfxml, abox)
        results[label] = "consistent" if consistent else "inconsistent"
        if consistent is None:
            problems.append(f"{label}: reasoner unavailable")
        elif consistent != expect_consistent:
            problems.append(
                f"{label}: expected {'consistent' if expect_consistent else 'inconsistent'}, "
                f"got {'consistent' if consistent else 'inconsistent'}"
            )

    inferred = classify(owl_dir / "example-abox.ttl")
    named_type_names = {named.owl_class for named in load_kernel().named_types}
    results["inferred_named_types"] = {
        individual: [cls for cls in classes if cls in named_type_names]
        for individual, classes in inferred.items()
        if any(cls in named_type_names for cls in classes)
    }
    expected_inferences = {
        "FRCPClash": "RepairFailure",
        "ICD11Residual": "ResidualIndeterminacy",
    }
    for individual, expected in expected_inferences.items():
        if expected not in inferred.get(individual, []):
            problems.append(
                f"{individual}: expected the reasoner to classify it as {expected}, got "
                f"{inferred.get(individual)}"
            )

    results["ok"] = not problems
    results["problems"] = problems
    results["note"] = (
        "Three checks. The gating-violation and mask-violation files must each make the "
        "ontology inconsistent; if they do not, those rules are documented but not "
        "enforced. And named types are defined classes, so the reasoner must classify a "
        "modal clash part of a remedy specification as a repair failure without being "
        "told: a domain typology is a theorem of the product, and this is what that "
        "amounts to in practice."
    )
    return results


def classify(abox_path: Path) -> dict[str, list[str]]:
    """Return the classes a reasoner infers for each named individual."""
    import tempfile

    try:
        from rdflib import Graph, URIRef
        import owlready2
    except ImportError:  # pragma: no cover
        return {}

    owl_dir = _root() / "spec" / "owl"
    rdfxml = owl_dir / "recognition-kernel.owl"
    if not rdfxml.is_file() or not abox_path.is_file():
        return {}

    graph = Graph()
    graph.parse(rdfxml, format="xml")
    graph.parse(abox_path, format="turtle")
    if not _merge_upstream(graph):
        stub = owl_dir / "bfo-stub.ttl"
        if stub.is_file():
            graph.parse(stub, format="turtle")
    graph.remove((None, URIRef("http://www.w3.org/2002/07/owl#imports"), None))

    with tempfile.NamedTemporaryFile(suffix=".owl", delete=False) as handle:
        merged = Path(handle.name)
    graph.serialize(destination=merged, format="xml")

    world = owlready2.World()
    try:
        onto = world.get_ontology(merged.as_uri()).load()
        with onto:
            owlready2.sync_reasoner(world, infer_property_values=False, debug=0)
        return {
            individual.name: sorted(
                cls.name for cls in individual.is_a if hasattr(cls, "name")
            )
            for individual in onto.individuals()
        }
    except Exception:  # pragma: no cover
        return {}
    finally:
        merged.unlink(missing_ok=True)


def _merge_upstream(graph) -> bool:
    """Merge the real BFO, IAO and RO into the graph. False if unreachable."""
    sources = [
        "http://purl.obolibrary.org/obo/bfo/2020/bfo.owl",
        "http://purl.obolibrary.org/obo/iao.owl",
        "http://purl.obolibrary.org/obo/ro.owl",
    ]
    merged = 0
    for source in sources:
        try:
            graph.parse(source)
            merged += 1
        except Exception:
            pass
    return merged == len(sources)


def _bfo_available() -> bool:
    """Whether the BFO import resolves in this environment.

    A consistency verdict reached without BFO's axioms present is a weaker
    claim than it looks: nothing can conflict with disjointness axioms that were
    never loaded. The scope of the check is therefore reported alongside it.
    """
    try:
        from rdflib import Graph

        Graph().parse("http://purl.obolibrary.org/obo/bfo/2020/bfo.owl")
        return True
    except Exception:
        return False


def _is_consistent(tbox_path: Path, abox_path: Path) -> bool | None:
    """Merge TBox and ABox and run HermiT. None if the reasoner cannot run."""
    import tempfile

    try:
        from rdflib import Graph
        import owlready2
    except ImportError:  # pragma: no cover
        return None

    graph = Graph()
    graph.parse(tbox_path, format="xml")
    graph.parse(abox_path, format="turtle")

    # Resolve the BFO import if we can; otherwise fall back to bare declarations.
    # Without either, `obo:BFO_0000050` is undeclared, every restriction built on
    # it is inert, and the gating axiom silently stops firing while the run still
    # reports consistent. A check that passes for that reason is worse than none.
    if not _merge_upstream(graph):
        stub = tbox_path.parent / "bfo-stub.ttl"
        if stub.is_file():
            graph.parse(stub, format="turtle")
    # owlready2 chokes on owl:imports it cannot resolve; the TBox is already merged.
    graph.remove((None, __import__("rdflib").URIRef("http://www.w3.org/2002/07/owl#imports"), None))

    with tempfile.NamedTemporaryFile(suffix=".owl", delete=False) as handle:
        merged = Path(handle.name)
    graph.serialize(destination=merged, format="xml")

    world = owlready2.World()
    try:
        onto = world.get_ontology(merged.as_uri()).load()
        with onto:
            owlready2.sync_reasoner(world, infer_property_values=False, debug=0)
        return True
    except owlready2.OwlReadyInconsistentOntologyError:
        return False
    except Exception:  # pragma: no cover - reasoner or java missing
        return None
    finally:
        merged.unlink(missing_ok=True)


def run_all(kernel_path: str | Path | None = None) -> dict:
    kernel = load_kernel(kernel_path)
    checks = [
        check_kernel(kernel),
        check_schemas(Path(kernel_path) if kernel_path else None),
        check_owl_agreement(kernel),
        check_reasoning(),
    ]
    ok = all(check["ok"] is not False for check in checks)

    lines = ["# Validation report", ""]
    for check in checks:
        if check["ok"] is None:
            mark = "skipped"
        elif check["ok"]:
            mark = "pass"
        else:
            mark = "FAIL"
        lines.append(f"- **{check['name']}**: {mark}")
        for key, value in check.items():
            if key in ("name", "ok") or not value:
                continue
            lines.append(f"    - {key}: {value}")
    lines.append("")
    lines.append(
        f"Kernel {kernel.kernel_version}: {len(kernel.primitives)} primitives over "
        f"{len(kernel.chain_loci)} chain loci plus the artifact body."
    )

    return {"ok": ok, "checks": checks, "markdown": "\n".join(lines)}
