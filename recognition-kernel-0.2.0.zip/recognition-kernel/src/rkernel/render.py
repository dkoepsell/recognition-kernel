"""Renderers for generated typologies: markdown grid, profile table, CSV."""

from __future__ import annotations

import csv
import io

from .kernel import Kernel, load_kernel

GLYPH = {
    "fires": "\u2713",         # can fire
    "rare": "\u25cb",          # fires only rarely
    "cannot_fire": "\u2717",   # cannot fire
    "not_applicable": "\u00b7",  # crossing not well-formed
}

GLYPH_LEGEND = (
    "\u2713 fires \u00b7 \u25cb fires only rarely \u00b7 \u2717 cannot fire "
    "\u00b7 \u00b7 crossing not well-formed at this locus"
)


def _cell(crossing: dict, keys: bool) -> str:
    glyph = GLYPH[crossing["firing"]]
    if keys and crossing.get("named_type"):
        return f"{glyph} **{crossing['named_type']}**"
    return glyph


def grid_markdown(typology: dict, kernel: Kernel | None = None, keys: bool = True,
                  include_artifact: bool = True) -> str:
    """Render the typology as the paper's Table 7 shape."""
    kernel = kernel or load_kernel()
    loci = [
        locus
        for locus in kernel.loci
        if include_artifact or not locus.pseudo_locus
    ]
    by_coord = {(c["primitive"], c["locus"]): c for c in typology["crossings"]}

    header = "| | " + " | ".join(locus.label for locus in loci) + " |"
    divider = "| --- " * (len(loci) + 1) + "|"
    lines = [header, divider]
    for primitive in kernel.primitives:
        cells = [
            _cell(by_coord[(primitive.id, locus.id)], keys) for locus in loci
        ]
        lines.append(f"| {primitive.id} | " + " | ".join(cells) + " |")

    counts = typology["counts"]
    caption = (
        f"\n*{typology['system_label']} \u2014 {typology['computed_kind'].replace('_', ' ')}, "
        f"{typology['chain_thickness']['summary']}. "
        f"{counts['well_formed']} of {counts['cells_total']} crossings well-formed; "
        f"{counts['fires']} fire, {counts['rare']} rare, {counts['cannot_fire']} cannot fire. "
        f"{GLYPH_LEGEND}.*"
    )
    return "\n".join(lines) + "\n" + caption


def status_row(typology: dict, kernel: Kernel | None = None) -> str:
    """The chain's link statuses as a one-row table."""
    kernel = kernel or load_kernel()
    loci = kernel.chain_loci
    by_coord = {(c["primitive"], c["locus"]): c for c in typology["crossings"]}
    statuses = []
    for locus in loci:
        sample = next(
            by_coord[(p.id, locus.id)] for p in kernel.primitives
        )
        statuses.append(sample["link_status"] or "-")
    header = "| Link | " + " | ".join(locus.label for locus in loci) + " |"
    divider = "| --- " * (len(loci) + 1) + "|"
    return "\n".join([header, divider, "| Status | " + " | ".join(statuses) + " |"])


def profile_markdown(typology: dict, kernel: Kernel | None = None) -> str:
    kernel = kernel or load_kernel()
    lines = [
        "| Stratum | Precondition | Gated | Profile |",
        "| --- | --- | --- | --- |",
    ]
    for stratum in kernel.strata:
        value = typology["profile"][stratum.id]
        lines.append(
            f"| {stratum.id} \u2014 {stratum.label} | {stratum.precondition} | "
            f"{'yes' if stratum.gated else 'no'} | {value.replace('_', ' ')} |"
        )
    return "\n".join(lines)


def _detector_cell(operationalized) -> str:
    """Report a partial detector as partial.

    `detectable_in_this_release` is a boolean and collapses `partial` into
    `True`, which in a table headed "Detector in this release" reads as a
    working detector. K-D2 is implemented for the text-internal case only and
    is low recall by construction, so it must not appear alongside K-D3.
    """
    if operationalized is True:
        return "yes"
    if operationalized == "partial":
        return "partial"
    return "no"


def predicted_markdown(typology: dict, limit: int | None = None) -> str:
    rows = typology["predicted_failure_modes"]
    total = len(rows)
    with_detector = sum(1 for row in rows if row.get("operationalized") is True)
    partial = sum(1 for row in rows if row.get("operationalized") == "partial")
    if limit:
        rows = rows[:limit]
    lines = [
        f"{total} crossings can fire. {with_detector} have a detector in this release "
        f"and {partial} a partial one; the remaining {total - with_detector - partial} are "
        "predictions with no instrument behind them yet."
        + (f" Showing the first {limit}." if limit and limit < total else ""),
        "",
        "| Primitive | Name | Stratum | Locus | Firing | Named type | Instrument | Detector in this release |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            "| {primitive} | {primitive_name} | {stratum} | {locus} | {firing} | "
            "{named} | {instrument} | {detect} |".format(
                primitive=row["primitive"],
                primitive_name=row["primitive_name"],
                stratum=row["stratum"],
                locus=row["locus"],
                firing=row["firing"],
                named=row["named_type"] or "\u2014",
                instrument=(row["instrument"] or "\u2014").replace("_", " "),
                detect=_detector_cell(row["operationalized"]),
            )
        )
    return "\n".join(lines)


def report_markdown(typology: dict, kernel: Kernel | None = None,
                    limit: int | None = None) -> str:
    """A complete human-readable report for one system."""
    kernel = kernel or load_kernel()
    parts = [
        f"# Typology: {typology['system_label']}",
        "",
        f"Generated by `{typology['generated_by']}` on {typology['generated_on']} "
        f"against kernel {typology['kernel_version']}.",
        "",
        "## Chain",
        "",
        status_row(typology, kernel),
        "",
        f"Computed kind: **{typology['computed_kind'].replace('_', ' ')}** "
        f"({typology['chain_thickness']['summary']}).",
    ]
    if typology["declared_kind"]:
        parts.append(
            f"Declared kind: {typology['declared_kind'].replace('_', ' ')}"
            + ("  \u2014 **mismatch with computed kind**" if typology["kind_mismatch"] else "")
        )
    parts += [
        "",
        "## Gated profile",
        "",
        profile_markdown(typology, kernel),
        "",
        "## Full typology (kernel \u00d7 chain)",
        "",
        grid_markdown(typology, kernel),
        "",
        "## Predicted failure modes",
        "",
        predicted_markdown(typology, limit=limit),
        "",
        "## Reporting constraints",
        "",
    ]
    parts += [f"- {constraint}" for constraint in typology["reporting_constraints"]]
    return "\n".join(parts) + "\n"


def crossings_csv(typology: dict) -> str:
    buffer = io.StringIO()
    fieldnames = [
        "primitive", "stratum", "locus", "link_status", "well_formed",
        "firing", "gated", "named_type", "instrument",
        "detectable_in_this_release",
    ]
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for crossing in typology["crossings"]:
        writer.writerow(crossing)
    return buffer.getvalue()


def comparison_markdown(comparison: dict, kernel: Kernel | None = None) -> str:
    kernel = kernel or load_kernel()
    stratum_ids = [stratum.id for stratum in kernel.strata]
    lines = [
        "| System | Computed kind | Chain thickness | "
        + " | ".join(stratum_ids)
        + " | Cells firing |",
        "| --- " * (5 + len(stratum_ids)) + "|",
    ]
    for system in comparison["systems"]:
        profile_cells = [
            system["profile"][stratum_id].replace("_", " ") for stratum_id in stratum_ids
        ]
        lines.append(
            f"| {system['label']} | {system['computed_kind'].replace('_', ' ')} | "
            f"{system['thickness']} | " + " | ".join(profile_cells) + f" | {system['fires']} |"
        )

    if any("profile_by_locus" in system for system in comparison["systems"]):
        loci = [locus.id for locus in kernel.chain_loci]
        lines += [
            "",
            "Stratum D by locus. The summary column above is keyed to the recognition act "
            "and therefore reports the same value for a classification and a certification "
            "scheme. They differ here, which is the measurement the registered design turns on.",
            "",
            "| System | " + " | ".join(loci) + " |",
            "| --- " * (len(loci) + 1) + "|",
        ]
        for system in comparison["systems"]:
            row = system.get("profile_by_locus", {}).get("D", {})
            lines.append(
                f"| {system['label']} | "
                + " | ".join(row.get(locus, "\u2014").replace("_", " ") for locus in loci)
                + " |"
            )
    return "\n".join(lines)
